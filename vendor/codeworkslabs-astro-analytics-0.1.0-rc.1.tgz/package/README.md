# Analytics for Astro

Add Fathom, Plausible, Google Analytics 4, Matomo or Umami to an Astro or
Starlight site. Configure one provider or several together and use one browser
API to send custom events.

The integration handles pageviews on ordinary pages and Astro ClientRouter
navigation. It also lets your consent interface grant or withdraw tracking
permission without reloading the page.

## Get started

- [Install and configure an Astro site](docs/getting-started.md)
- [Use the Starlight plugin](docs/starlight.md)
- [Connect providers](docs/configuration.md)
- [Send custom events](docs/events.md)
- [Check tracking and troubleshoot](docs/verification-and-troubleshooting.md)

This is a prerelease. See [Versions and availability](docs/versioning-and-releases.md)
for the current test package and installation method.

## A small example

After [installing the package](docs/getting-started.md#1-install-the-package),
add it to your Astro configuration:

```js
// astro.config.mjs
import { defineConfig } from "astro/config";
import analytics from "@codeworkslabs/astro-analytics";

export default defineConfig({
  integrations: [analytics({
    providers: [{ name: "fathom", siteId: "YOUR-SITE-ID" }],
    events: true,
  })],
});
```

This example starts tracking immediately. See [Pageviews and privacy](docs/runtime-and-safety.md)
to wait for consent or exclude sensitive URLs.

Custom events report whether each local adapter accepted the call, not whether
its server received it. Your site supplies its consent UI and persistence;
the integration does not include an event queue or retry service.

## More information

[API reference](docs/api-reference.md) · [Contributing](docs/development.md) ·
[Release notes](CHANGELOG.md)
