# Analytics for Astro documentation

Connect your Astro website to Fathom, Plausible, Google Analytics 4, Matomo or
Umami. Use one provider or several together, without adding separate tracking
snippets to your pages. Starlight sites use the same settings through a plugin.

Analytics for Astro handles pageviews and gives you one browser API for custom
events, such as a newsletter signup or a download. You can also wait for a
visitor's consent before loading tracking scripts.

## Start here

- **Adding analytics to an Astro site?** Follow [Getting started](getting-started.md).
- **Using Starlight?** Follow [Starlight integration](starlight.md).
- **Choosing or connecting providers?** See [Configuration](configuration.md).
- **Tracking a button or another action?** See [Custom events](events.md).
- **Checking whether data arrived?** Use [Verify tracking and troubleshoot](verification-and-troubleshooting.md).

## What it handles

Pageviews work on ordinary page loads and Astro ClientRouter navigation. With
several providers configured, a single event is offered to each one and you can
inspect each result separately.

Consent controls let your site grant or withdraw permission to make tracking
calls. Your site supplies the consent interface and remembers the visitor's
choice. The package does not include a consent banner.

An event result tells you whether the local adapter accepted the call. It does
not confirm that an analytics server received it. Events are not queued or
retried; the verification guide shows how to check delivery.

## Explore further

| I want to… | Read |
| --- | --- |
| Understand pageviews, consent and sensitive URLs | [Pageviews and privacy](runtime-and-safety.md) |
| Look up a function, result or type | [API reference](api-reference.md) |
| Work on the package | [Contributing and testing](development.md) |
| Check availability and version compatibility | [Versions and availability](versioning-and-releases.md) |
| See what changed | [Release notes](../CHANGELOG.md) |

Testing RC.1? See [Versions and availability](versioning-and-releases.md) for the
current release and supported versions.
