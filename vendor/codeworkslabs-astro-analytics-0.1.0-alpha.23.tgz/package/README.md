# Analytics for Astro

`@codeworkslabs/astro-analytics` is an experimental Astro integration for
Fathom, Plausible, Google Analytics 4, Matomo, and Umami. The current source is
`0.1.0-alpha.23` and is not published to npm.

It supports multiple providers at once, Astro and ClientRouter pageview
lifecycle handling, runtime consent transitions, bounded custom events,
per-provider status/results, an optional blocked-query privacy boundary, and a
Starlight wrapper.

## Quick start

Install an authorized package artifact, then configure one or more providers:

```js
// astro.config.mjs
import { defineConfig } from "astro/config";
import analytics from "@codeworkslabs/astro-analytics";

export default defineConfig({
  integrations: [
    analytics({
      providers: [
        { name: "fathom", siteId: "YOUR-SITE-ID" },
      ],
      events: true,
      blockedQueryParameters: ["preview"],
    }),
  ],
});
```

`providers` is required. Set it to `false` to disable the integration. The
singular `provider` input and object-shaped `events` compatibility input are not
part of the current contract.

The default environment policy injects analytics only during production builds.
Provider script URLs must use HTTPS. `blockedQueryParameters` prevents first
provider activation on matching URLs and suppresses later package pageview and
custom-event dispatch there. Already-initialized scripts, globals and the public
client can remain present. The package excludes blocked URLs from the referrer
context it supplies; these gates do not retract executed vendor code or prove
the absence of autonomous provider requests.

## Client events

```ts
import {
  configuredProviders,
  consentStatuses,
  providerStatuses,
  setConsent,
  track,
} from "@codeworkslabs/astro-analytics/client";

// Invoke after the site has obtained the visitor's grant.
setConsent("granted");
const result = track("purchase", { plan: "pro", value: 25 });
console.log(result.providers);
console.log(configuredProviders(), consentStatuses(), providerStatuses());
```

The browser client is installed for consent and status control; `events: true`
also enables `track()`. Each provider returns its own `ready`,
`adapter-not-loaded`, `consent-pending`, `consent-denied`, or `invalid-event`
outcome. Calls are synchronous and confirm local adapter acceptance, not server
delivery.

## Current limitations

- Deferred and external consent modes implement basic consent: vendors do not
  load until `setConsent("granted")`. Withdrawal blocks later package dispatch,
  but cannot retract data already sent or erase already-executed vendor code.
- GA4 provider-owned pageviews are the ordinary default. Explicit
  `pageviews: "astro"` requires `historyPageviewsDisabled: true`, the operator's
  assertion that GA history-based page changes are disabled. The package cannot
  verify that setting. GA4 `pageviews: "none"` is unsupported; use
  `providers: false` to turn this integration completely off.
- Events are not queued before adapters become ready.
- Fathom forwards only `_value`; Matomo maps `_name` and `_value`; the other
  adapters apply their documented provider limits.
- The package ships TypeScript source and is intended for Astro or another
  TypeScript-aware build pipeline.
- The package remains npm-unpublished and retains `private: true`.

## Documentation

- [Getting started](docs/getting-started.md)
- [Configuration](docs/configuration.md)
- [API reference](docs/api-reference.md)
- [Event client](docs/events.md)
- [Starlight](docs/starlight.md)
- [Runtime behavior](docs/runtime-and-safety.md)
- [Development](docs/development.md)
- [Versioning and releases](docs/versioning-and-releases.md)
- [Changelog](CHANGELOG.md)

## Local verification

```powershell
npm ci
npm run verify
```

`npm run verify` performs strict TypeScript checking and runs the Node test
suite. Repository guidance is in `AGENTS.md`.
